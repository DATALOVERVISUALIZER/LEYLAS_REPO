---------------------------------------------------------------------
-- Microsoft SQL Server 2012 T-SQL Fundamentals
-- Chapter 01 - Background to T-SQL Querying and Programming
-- � Itzik Ben-Gan 
---------------------------------------------------------------------

---------------------------------------------------------------------
-- Creating Tables
---------------------------------------------------------------------

-- Create table Employees
USE TSQL2012;

IF OBJECT_ID('dbo.Employees', 'U') IS NOT NULL
  DROP TABLE dbo.Employees;

Insert into [ETL_HE].dbo.Employees
select * from [ETL_HE].[dbo].[Tableau_Emlakci_ilan_Oranlama_Yedek_3012016]

CREATE TABLE dbo.Employees
(
  empid     INT         NOT NULL,
  firstname VARCHAR(30) NOT NULL,
  lastname  VARCHAR(30) NOT NULL,
  hiredate  DATE        NOT NULL,
  mgrid     INT         NULL,
  ssn       VARCHAR(20) NOT NULL,
  salary    MONEY       NOT NULL
);

select * from [ETL_HE].[dbo].[AAemployee-test]
---------------------------------------------------------------------
-- Data Integrity
---------------------------------------------------------------------

-- Primary key--empid primary key olarak eklendi.

ALTER TABLE [ETL_HE].[dbo].[AAemployee-test]
  
-- Unique
ALTER TABLE [ETL_HE].[dbo].[AAemployee-test]
  ADD CONSTRAINT UNQ_Employees_ssn
  UNIQUE([  ssn  ]); -- ssn numaras� unique constraint olarak atand�, boylece her ssn numaras� tekrarlamadan unique olarak grilmek zorunda

-- Table used in foreign key example
IF OBJECT_ID('dbo.Orders', 'U') IS NOT NULL -- Order table '� var m� yok mu kontrol edilir. 
  DROP TABLE dbo.Orders;  -- e�er tablo varsa tablo silinir.
   
CREATE TABLE dbo.Orders
(
  orderid   INT         NOT NULL,
  empid     INT         NOT NULL,
  custid    VARCHAR(10) NOT NULL,
  orderts   DATETIME2   NOT NULL,
  qty       INT         NOT NULL,
  CONSTRAINT PK_Orders
    PRIMARY KEY(orderid)
);

ALTER TABLE [ETL_HE].[dbo].[AA_orders-test]
ADD CONSTRAINT fk_Orders_Employees
FOREIGN KEY(empid)
references [dbo].[AAemployee-test](empid)

-- Foreign keys
ALTER TABLE [ETL_HE].[dbo].[AA_orders-test]
  ADD CONSTRAINT FK_Orders_Employees
  FOREIGN KEY([empid ])
  REFERENCES [ETL_HE].[dbo].[AAemployee-test](empid);

ALTER TABLE dbo.Employees
  ADD CONSTRAINT FK_Employees_Employees
  FOREIGN KEY(mgrid)
  REFERENCES dbo.Employees(empid);

-- Check
ALTER TABLE [ETL_HE].[dbo].[AAemployee-test] -- Constraint checks the salary whether it is positive or negative 
  ADD CONSTRAINT CHK_Employees_salary
  CHECK( [  salary]> 0.00);

-- Default
ALTER TABLE dbo.Orders
  ADD CONSTRAINT DFT_Orders_orderts
  DEFAULT(SYSDATETIME()) FOR orderts;

--Default order time constraint ile SYSDATETIME() olarak atand� 
  ALTER TABLE [ETL_HE].[dbo].[AA_orders-test]
  ADD CONSTRAINT DFT_Orders_Orderts
  DEFAULT(SYSDATETIME()) For [  orderts]

-- Cleanup --Tablea are clean up 
DROP TABLE [ETL_HE].[dbo].[AA_orders-test],[ETL_HE].[dbo].[AAemployee-test]

DECLARE @x SQL_VARIANT=258 --th,s data teype allows you to stor any data type 
select @x,
SQL_VARIANT_PROPERTY(@x,'basetype')

set @x='Scott'
select @x, 
SQL_VARIANT_PROPERTY(@x,'basetype')--Sql_variant_property ile basetype yaz�larak de�i�kenin data type � ��ren�leblir.

select * from dbo.ArchiveTable_Sosyal_Medya_30112015;
select * from [dbo].[Tableau_gunluk_ilan_sayisi]

declare @I INT='Scott'
Select @I

select * from dbo.Tableau_Emlakci_ilan_Oranlama_Yedek_3012016  as a 
where a.tarih=convert(datetime,'31.12.2015',103)
order by a.Tarih 

-- vreate or reuse a plan 
-- compiled plan 

select a.Tarih,b.bolge,
sum(a.[ilan _Say�s�]) as ilan_toplam
from dbo.Tableau_gunluk_ilan_sayisi as a 
JOIN [dbo].[Tableau_satis_bolgesi] as b
On a.�l=b.�l and a.�lce=b.�lce
where a.tarih=convert(datetime,'04.01.2016',103)
group by a.Tarih,b.bolge
order by ilan_toplam desc 

select * from dbo.Tableau_satis_bolgesi




